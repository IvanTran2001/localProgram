class A {
public:
    A();
    virtual ~A();
    
    virtual int foo();
    virtual int foo(int x);
};
