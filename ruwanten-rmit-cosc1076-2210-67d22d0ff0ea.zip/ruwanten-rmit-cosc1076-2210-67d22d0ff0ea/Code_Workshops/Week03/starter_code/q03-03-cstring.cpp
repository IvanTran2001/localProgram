
#include <iostream>

int main (void) {

   char hello[] = "Hello World";

   std::cout << hello << std::endl;
   
   // Make second output just print "Hello"
   // ??

   std::cout << hello << std::endl;

   return EXIT_SUCCESS;
}
