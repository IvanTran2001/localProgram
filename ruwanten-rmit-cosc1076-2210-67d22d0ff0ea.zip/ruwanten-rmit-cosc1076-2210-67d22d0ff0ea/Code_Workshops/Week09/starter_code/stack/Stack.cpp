#include "Stack.h"


Stack::Stack() {
}

Stack::Stack(const Stack& other) {
}

Stack::Stack(Stack&& other) {
}

Stack::~Stack() {
}

/**
 * Return the current size of the Stack.
 */
unsigned int Stack::size() const {
}

/**
 * Get the top element of the Stack
 */
int Stack::top() const {
}

/**
 * Add the value to the top of the Stack
 */
void Stack::push(int value) {
}

/**
 * Remove the element from the top of the Stack
 */
void Stack::pop() {
}

/**
 * Removes all elements from the Stack
 */
void Stack::clear() {
}

