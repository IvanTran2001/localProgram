
#include "BST.h"

#include <iostream>
#include <string>

BST::BST() {
}

BST::~BST() {
}

void BST::clear() {
}

bool BST::contains(const int data) const {
   return false;
}

void BST::add(const int data) {
}
