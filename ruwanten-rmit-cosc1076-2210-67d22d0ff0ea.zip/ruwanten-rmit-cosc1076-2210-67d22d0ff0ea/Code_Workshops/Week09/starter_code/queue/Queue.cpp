#include "Queue.h"

Queue::Queue() {
}

Queue::Queue(const Queue& other) {
}

Queue::Queue(Queue&& other) {
}

Queue::~Queue() {
}

unsigned int Queue::size() const {
}

int Queue::front() const {
}

void Queue::enqueue(int value) {
}

void Queue::dequeue() {
}

void Queue::clear() {
}