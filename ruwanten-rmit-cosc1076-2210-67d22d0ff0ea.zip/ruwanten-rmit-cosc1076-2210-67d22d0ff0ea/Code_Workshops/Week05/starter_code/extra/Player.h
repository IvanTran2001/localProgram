#ifndef PLAYER_H
#define PLAYER_H 

#define MAX_HAND_SIZE        5
#define MAX_PALETTE_SIZE     MAX_HAND_SIZE

class Player {
public:
    // TODO

private:
};

#endif // PLAYER_H
