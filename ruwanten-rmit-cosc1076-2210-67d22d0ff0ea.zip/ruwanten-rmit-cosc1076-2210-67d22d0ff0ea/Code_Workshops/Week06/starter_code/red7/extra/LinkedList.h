#ifndef LINKEDLIST
#define LINKEDLIST

#include "Card.h"

class Node{
public:
    
};

class LinkedList{
public:
    

private:
    
};


#endif //LINKEDLIST