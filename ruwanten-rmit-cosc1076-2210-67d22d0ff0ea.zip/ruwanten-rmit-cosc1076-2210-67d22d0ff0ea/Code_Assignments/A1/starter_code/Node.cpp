
#include "Node.h"


Node::Node(int row, int col, int distanceToS){
   //TODO
}
    
Node::~Node(){
   //TODO
}

int Node::getRow(){
   //TODO
}

int Node::getCol(){
   //TODO
}

int Node::getDistanceToS(){
   //TODO
}

void Node::setDistanceToS(int distanceToS){
   //TODO
}
