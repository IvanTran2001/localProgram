
#include "NodeList.h"
#include <iostream>



NodeList::NodeList(){
   
}


NodeList::~NodeList(){
   
}

NodeList::NodeList(NodeList& other){
    // TODO
}


int NodeList::getLength(){
   
}


NodePtr NodeList::get(int i){
   
}

void NodeList::addBack(NodePtr newNode){
   
}

bool NodeList::containsNode(NodePtr node){
   
}

void NodeList::clear(){
   
}