
#include "LinkedList.h"

#include <iostream>
#include <fstream>

Node::Node(int value, Node* next) :
   value(value),
   next(next)
{}

LinkedList::LinkedList() 
{
   // TODO
}

LinkedList::LinkedList(LinkedList& other) 
{
   // TODO
}

LinkedList::~LinkedList() {
   // TODO
}

int LinkedList::size() {
   // TODO
   return 0;
}

int LinkedList::get(int index) {
   // TODO
   return 0;
}

void LinkedList::addFront(int value) {
   // TODO
}

void LinkedList::addBack(int value) {
   // TODO
}

void LinkedList::removeBack() {
   // TODO
}

void LinkedList::removeFront() {
   // TODO
}

void LinkedList::clear() {
   // TODO
}

