
#include <iostream>

int main (void) {

   int      i;
   std::cout << "What Happens now?" << std::endl;
   std::cout << "i: " << i << std::endl;

   return EXIT_SUCCESS;
}
