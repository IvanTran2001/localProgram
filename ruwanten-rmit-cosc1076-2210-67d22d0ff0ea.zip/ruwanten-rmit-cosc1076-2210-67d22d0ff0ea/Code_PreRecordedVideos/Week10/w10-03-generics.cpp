#include <iostream>

int main(void) {

   int x = 5;
   int exponent = 3;

   int result = 125;
   std::cout << x << "^" << exponent
             << " = " << result << std::endl;

   return EXIT_SUCCESS;
}
