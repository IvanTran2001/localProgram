#include <iostream>
#include <string>

#include <array>
#include <deque>
#include <list>
#include <map>
#include <set>
#include <utility>
#include <vector>

int main(void) {

   // Array - special initialisation

   // Vector

   // List

   // Deque

   // Map

   // Tuple

   return EXIT_SUCCESS;
}
