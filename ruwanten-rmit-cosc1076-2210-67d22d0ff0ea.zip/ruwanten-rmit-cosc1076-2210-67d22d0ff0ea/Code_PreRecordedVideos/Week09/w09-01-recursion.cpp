#include <iostream>
#include <string>

int main(void) {

   // Implement factorial

   return EXIT_SUCCESS;
}
