#include <iostream>

#include "Card.h"

int main(void) {

   Card card1(RED, 7);
   Card card2(RED, 6);
   Card card3(ORANGE, 7);
   Card card4(RED, 7);

   return EXIT_SUCCESS;
}
 