#include <iostream>

// typedef int   Integer;
// typedef int*  IntegerPtr;

int main(void) {

    // Integer x = 10;
    // IntegerPtr ptr = &x;

    // std::cout << x << std::endl;
    // std::cout << ptr << std::endl;
    // std::cout << *ptr << std::endl;

    return EXIT_SUCCESS;
}
