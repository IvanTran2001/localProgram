// #ifndef PRINT_H
// #define PRINT_H

#include "Boat.h"

// void printBoat(Boat* boat);
void printBoat(Boat& boat);
// #endif // PRINT_H
