
#include <iostream>
#include <string>

class Boat {

};

int main(void) {
   

   return EXIT_SUCCESS;
}


