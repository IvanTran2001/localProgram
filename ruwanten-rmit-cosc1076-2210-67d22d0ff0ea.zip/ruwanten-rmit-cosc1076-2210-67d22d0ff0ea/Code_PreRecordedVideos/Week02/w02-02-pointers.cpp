
#include <iostream>

int main (void) {

   int a = 1;
   int b = 2;
   int c = 3;

   std::cout << &a << " " << a << std::endl;
   std::cout << &b << " " << b <<  std::endl;
   std::cout << &c << " " << c <<  std::endl;


   return EXIT_SUCCESS;
}
