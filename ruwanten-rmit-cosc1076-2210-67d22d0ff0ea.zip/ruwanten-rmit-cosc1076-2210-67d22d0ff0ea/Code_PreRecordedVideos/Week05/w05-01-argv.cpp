#include <iostream>

int main(void) {

    std::cout << "Received Command Line Arguements" << std::endl;

    return EXIT_SUCCESS;
}
